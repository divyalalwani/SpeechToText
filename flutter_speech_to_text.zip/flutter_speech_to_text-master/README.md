# flutter_speech_to_text

### In this Flutter Video, we take a look at how to build a Speech to Text application.  This includes setting up the plugin to pass messages back and forth between the platforms. 

### To build this application, you will need the latest version of the flutter SDK.  
### Check out the Youtube Tutorial for this [Dart Flutter Program](https://youtu.be/-rQ_OmPj300). Here is our [Youtube Channel](https://www.youtube.com/channel/UCYqCZOwHbnPwyjawKfE21wg) Subscribe for more content.

### Check out our blog at [tensor-programming.com](http://tensor-programming.com/).

### Our [Twitter](https://twitter.com/TensorProgram), our [facebook](https://www.facebook.com/Tensor-Programming-1197847143611799/) and our [Steemit](https://steemit.com/@tensor).
