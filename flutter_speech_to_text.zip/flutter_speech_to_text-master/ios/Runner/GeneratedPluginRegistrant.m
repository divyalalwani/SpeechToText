//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <speech_recognition/SpeechRecognitionPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [SpeechRecognitionPlugin registerWithRegistrar:[registry registrarForPlugin:@"SpeechRecognitionPlugin"]];
}

@end
